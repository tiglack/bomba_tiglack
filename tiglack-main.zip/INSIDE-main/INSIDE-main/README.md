<div align="center">

![Screenshot_1](https://telegra.ph/file/c87fdb1c5faad4ee53050.png)

# 💣 TIGLACK BOMBER

Мощный, кроссплатформенный, SMS/CALL/FEEDBACK Бомбер с графическим и web интерфейсом! Более 330+ рабочих сервисов! А благодаря асинхронной работе - данный бомбер не только мощный, но и быстрый! Также присутствует такой тип атаки как FEEDBACK, что является уникальной фишкой!<br><br>На данный момент, бомбер отлично спамит на номера таких стран как Россия и Узбекистан, также есть сервисы и для других стран! В будущем планируется добавить сервисы всех стран СНГ!
<br><br><br>
**Используйте этот скрипт исключительно в образовательных целях, избегая злоупотребления. Вы полностью несете ответственность за любое его использование!**

</div>

# 🐧 Linux
- **Установка**
  ```
  git clone https://github.com/A-KTO-Tbl/TIGLACK && cd TIGLACK && pip3 install -r Core/requirements.txt
  ```
- **Запуск с графическим интерфейсом**
  ```
  python3 GUI.py
  ```
- **Запуск с web интерфейсом**
  ```
  python3 WEB.py
  ```

# 💻 Windows
- **Для использования TIGLACK на Windows, у Вас есть два варианта**
  - Скачать готовую скомпилированную программу ~> **[СКАЧАТЬ](https://github.com/A-KTO-Tbl/TIGLACK/releases/download/1.07/TIGLACK.1.07.exe)**
  - Использовать скрипт, по аналогии с [Linux](#-linux). Для этого способа требуется установить [Python](https://www.python.org)!

# 📱 Android
- **Подготовка**
  - Для использования TIGLACK на Android требуется установить [Termux](https://github.com/termux/termux-app/releases)!
  - Открываем Termux и вводим следующие команды
      ```
      pkg update && pkg upgrade -y && pkg install -y python git
      ```
- **Установка**
  ```
  git clone https://github.com/A-KTO-Tbl/TIGLACK && cd TIGLACK && pip install -r Core/requirements.txt
  ```
- **Запуск с web интерфейсом**
  ```
  python WEB.py
  ```

# ⚡️ Дополнительно
- **Наш Telegram канал ~> [КЛИК](https://t.me/+z4L61XedSVllODAy). Подписка на него - самая лучшая поддержка и мотивация продолжать данный проект💜**
- **[Владелец](https://t.me/A_KTO_Tbl)**
- **[DonationAlerts](https://www.donationalerts.com/r/TIGLACK_forever)**
