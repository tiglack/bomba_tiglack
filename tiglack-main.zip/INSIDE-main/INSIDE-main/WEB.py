from Core.Main import Start

Start(web=True)
